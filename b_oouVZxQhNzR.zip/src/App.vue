<template>
  <div :class="isDark ? 'dark' : ''">
    <div class="min-h-screen bg-gray-50 dark:bg-[#0d0d17] text-gray-900 dark:text-gray-100 transition-colors duration-300">
      <!-- Navbar -->
      <Navbar 
        :isDark="isDark"
        :currentLang="currentLang"
        :activePage="activePage"
        @toggle-sidebar="sidebarOpen = !sidebarOpen"
        @toggle-dark="toggleDark"
        @set-page="setActivePage" />

      <!-- Sidebar -->
      <Sidebar 
        :sidebarOpen="sidebarOpen"
        :isMobile="isMobile"
        :currentLang="currentLang"
        :activePage="activePage"
        @close="sidebarOpen = false"
        @set-page="setActivePage" />

      <!-- Main Content -->
      <main :class="['min-h-screen pt-16 transition-all duration-300',
                     sidebarOpen ? 'lg:pl-72' : 'lg:pl-0']">
        <!-- Home Page -->
        <HomePage v-if="activePage === 'home'" :currentLang="currentLang" />

        <!-- Dashboard Page -->
        <DashboardPage v-else-if="activePage === 'dashboard'" :currentLang="currentLang" />

        <!-- Other Pages Placeholder -->
        <div v-else class="px-4 md:px-6 lg:px-10 py-16 max-w-2xl mx-auto text-center">
          <div class="w-20 h-20 rounded-3xl bg-gradient-to-br from-brand-400 to-brand-700 flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-brand-500/30">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"/>
            </svg>
          </div>
          <h2 class="font-display font-bold text-3xl text-gray-900 dark:text-white mb-3">
            {{ currentLang === 'en' ? 'Coming Soon' : 'មកដល់ឆាប់ៗ' }}
          </h2>
          <p class="text-gray-500 dark:text-gray-400">
            {{ currentLang === 'en'
              ? 'This section is under construction. Check back soon!'
              : 'ផ្នែកនេះកំពុងស្ថាបនា។ ត្រឡប់មើលឆាប់ៗ!' }}
          </p>
        </div>

        <!-- Footer -->
        <Footer :currentLang="currentLang" />
      </main>

      <!-- Chat Widget -->
      <ChatWidget 
        :chatOpen="chatOpen"
        :currentLang="currentLang"
        @toggle-chat="chatOpen = !chatOpen" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import Navbar from './components/Navbar.vue'
import Sidebar from './components/Sidebar.vue'
import HomePage from './components/HomePage.vue'
import DashboardPage from './components/DashboardPage.vue'
import ChatWidget from './components/ChatWidget.vue'
import Footer from './components/Footer.vue'

// State
const isDark = ref(false)
const sidebarOpen = ref(true)
const isMobile = ref(false)
const currentLang = ref('en')
const activePage = ref('home')
const chatOpen = ref(false)

// Functions
const toggleDark = () => {
  isDark.value = !isDark.value
  if (isDark.value) {
    document.documentElement.classList.add('dark')
  } else {
    document.documentElement.classList.remove('dark')
  }
}

const setActivePage = (page) => {
  activePage.value = page
  sidebarOpen.value = false
}

const handleResize = () => {
  isMobile.value = window.innerWidth < 1024
  if (window.innerWidth >= 1024) {
    sidebarOpen.value = true
  } else {
    sidebarOpen.value = false
  }
}

// Lifecycle
onMounted(() => {
  handleResize()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
})
</script>

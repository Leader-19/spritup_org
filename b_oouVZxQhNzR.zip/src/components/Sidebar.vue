<template>
  <!-- Mobile Overlay -->
  <transition name="fade">
    <div 
      v-if="sidebarOpen && isMobile"
      class="fixed inset-0 z-30 overlay"
      @click="$emit('close')">
    </div>
  </transition>

  <!-- Sidebar -->
  <aside 
    :class="['sidebar-glass fixed left-0 top-16 bottom-0 z-30 w-72 overflow-y-auto transition-transform duration-300',
             sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
             !sidebarOpen && 'lg:w-0 lg:overflow-hidden']"
    style="transition: transform 0.3s cubic-bezier(.4,0,.2,1), width 0.3s;">

    <div class="p-4 space-y-6">
      <!-- Search -->
      <div class="relative">
        <svg xmlns="http://www.w3.org/2000/svg" class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
          <circle cx="11" cy="11" r="8"/><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-4.35-4.35"/>
        </svg>
        <input 
          type="text"
          :placeholder="currentLang === 'en' ? 'Search...' : 'ស្វែងរក...'"
          class="w-full pl-9 pr-4 py-2.5 rounded-xl bg-gray-100 dark:bg-gray-800/80 text-sm text-gray-700 dark:text-gray-300 placeholder-gray-400 border-none outline-none focus:ring-2 focus:ring-brand-400/50 transition"/>
      </div>

      <!-- Sidebar Categories -->
      <div v-for="category in sidebarCategories" :key="category.title" class="space-y-1">
        <p class="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500 px-3 mb-2">
          {{ currentLang === 'en' ? category.title : category.titleKh }}
        </p>

        <button 
          v-for="item in category.items" 
          :key="item.label"
          @click="handleNavClick(item.page)"
          :class="['w-full flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer transition-all text-sm font-medium text-left',
                   activePage === item.page
                     ? 'nav-active shadow-lg shadow-brand-500/25'
                     : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800/60 hover:text-gray-900 dark:hover:text-gray-100']">
          <span v-html="item.icon" class="w-4 h-4 flex-shrink-0"></span>
          <span>{{ currentLang === 'en' ? item.label : item.labelKh }}</span>
          <span 
            v-if="item.badge"
            class="ml-auto text-xs px-2 py-0.5 rounded-full bg-brand-500 text-white font-semibold">
            {{ item.badge }}
          </span>
          <span 
            v-if="item.new"
            class="ml-auto text-xs px-2 py-0.5 rounded-full bg-green-500 text-white font-semibold">
            {{ currentLang === 'en' ? 'New' : 'ថ្មី' }}
          </span>
        </button>
      </div>

      <!-- Upgrade Card -->
      <div class="mx-1 p-4 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-lg shadow-brand-500/30">
        <p class="font-display font-bold text-base mb-1">
          {{ currentLang === 'en' ? 'Upgrade to Pro' : 'ដំឡើងទៅ Pro' }}
        </p>
        <p class="text-xs opacity-80 mb-3">
          {{ currentLang === 'en' ? 'Unlock all features & unlimited access.' : 'បើកដំណើរការគ្រប់មុខងារ។' }}
        </p>
        <button class="w-full py-2 bg-white text-brand-600 rounded-lg text-xs font-semibold hover:bg-brand-50 transition-colors">
          {{ currentLang === 'en' ? 'Get Started' : 'ចាប់ផ្តើម' }}
        </button>
      </div>
    </div>
  </aside>
</template>

<script setup>
defineProps({
  sidebarOpen: Boolean,
  isMobile: Boolean,
  currentLang: String,
  activePage: String,
})

defineEmits(['close', 'set-page'])

const handleNavClick = (page) => {
  defineEmits(['set-page'])(page)
}

const sidebarCategories = [
  {
    title: 'Main',
    titleKh: 'ស្នូលក្នុង',
    items: [
      {
        label: 'Home',
        labelKh: 'ទំព័រដើម',
        page: 'home',
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-3m0 0l7-4 7 4M5 9v10a1 1 0 001 1h12a1 1 0 001-1V9m-9 11l4-4" /></svg>'
      },
      {
        label: 'Dashboard',
        labelKh: 'ផ្ទាំងគ្រប់គ្រង',
        page: 'dashboard',
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>'
      },
      {
        label: 'Analytics',
        labelKh: 'វិភាគ',
        page: 'analytics',
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>',
        new: true
      },
    ]
  },
  {
    title: 'Tools',
    titleKh: 'ឧបករណ៍',
    items: [
      {
        label: 'Projects',
        labelKh: 'គម្រោង',
        page: 'projects',
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>',
        badge: '5'
      },
      {
        label: 'Team',
        labelKh: 'ក្រុម',
        page: 'team',
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.856-1.487M15 10a3 3 0 11-6 0 3 3 0 016 0zM15 20H9m6 0h6" /></svg>'
      },
      {
        label: 'Settings',
        labelKh: 'ការកំណត់',
        page: 'settings',
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>'
      },
    ]
  },
]
</script>

<template>
  <div class="hero-bg min-h-[calc(100vh-4rem)]">
    <!-- Hero Section -->
    <section class="px-4 md:px-6 lg:px-10 pt-12 md:pt-16 pb-8 md:pb-12 max-w-6xl mx-auto">
      <div class="flex flex-col lg:flex-row items-center gap-8 lg:gap-12">
        <div class="flex-1 space-y-6 order-2 lg:order-1">
          <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-100 dark:bg-brand-900/40 text-brand-600 dark:text-brand-400 text-sm font-medium">
            <span class="w-2 h-2 rounded-full bg-brand-500 animate-pulse"></span>
            {{ currentLang === 'en' ? '✨ New: AI Assistant is live!' : '✨ ថ្មី: AI Assistant ដំណើរការហើយ!' }}
          </div>
          <h1 class="font-display font-extrabold text-4xl md:text-5xl lg:text-6xl leading-tight text-gray-900 dark:text-white">
            {{ currentLang === 'en' ? 'Build Faster.' : 'បង្កើតលឿន។' }}<br>
            <span class="gradient-text">{{ currentLang === 'en' ? 'Think Smarter.' : 'គិតឆ្លាត។' }}</span>
          </h1>
          <p class="text-base md:text-lg text-gray-600 dark:text-gray-400 max-w-xl leading-relaxed">
            {{ currentLang === 'en'
              ? 'Nexus is your all-in-one platform for managing, creating, and scaling — powered by cutting-edge AI.'
              : 'Nexus គឺជាវេទិការបស់អ្នកសម្រាប់គ្រប់គ្រង បង្កើត និងពង្រីក — ដំណើរការដោយ AI ទំនើប។' }}
          </p>
          <div class="flex flex-wrap gap-3">
            <button class="px-6 py-3 bg-brand-600 hover:bg-brand-700 text-white rounded-xl font-semibold text-sm shadow-lg shadow-brand-500/30 transition-all hover:-translate-y-0.5 active:translate-y-0">
              {{ currentLang === 'en' ? 'Get Started Free' : 'ចាប់ផ្តើមដោយឥតគិតថ្លៃ' }}
            </button>
            <button class="px-6 py-3 border border-gray-200 dark:border-gray-700 hover:border-brand-400 dark:hover:border-brand-500 text-gray-700 dark:text-gray-300 rounded-xl font-semibold text-sm transition-all hover:-translate-y-0.5">
              {{ currentLang === 'en' ? 'View Demo' : 'មើលការបង្ហាញ' }}
            </button>
          </div>
        </div>

        <!-- Stats Cards -->
        <div class="flex-1 grid grid-cols-2 gap-4 max-w-sm w-full order-1 lg:order-2">
          <div 
            v-for="stat in stats" 
            :key="stat.label"
            class="p-5 rounded-2xl bg-white/80 dark:bg-gray-800/80 glass border border-gray-100 dark:border-gray-700/50 shadow-sm hover:shadow-md transition-shadow">
            <p class="font-display font-bold text-3xl text-gray-900 dark:text-white">{{ stat.value }}</p>
            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">{{ currentLang === 'en' ? stat.label : stat.labelKh }}</p>
            <div class="mt-3 flex items-center gap-1 text-green-500 text-xs font-medium">
              <svg xmlns="http://www.w3.org/2000/svg" class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M5 15l7-7 7 7"/>
              </svg>
              {{ stat.change }}
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Feature Cards -->
    <section class="px-4 md:px-6 lg:px-10 py-8 md:py-12 max-w-6xl mx-auto">
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <div 
          v-for="feature in features" 
          :key="feature.title"
          class="p-6 rounded-2xl bg-white/80 dark:bg-gray-800/80 glass border border-gray-100 dark:border-gray-700/50 hover:border-brand-300 dark:hover:border-brand-700 transition-all hover:-translate-y-1 hover:shadow-lg group cursor-pointer">
          <div :class="['w-10 h-10 rounded-xl flex items-center justify-center text-white mb-4 shadow-lg', feature.color]">
            <span v-html="feature.icon" class="w-5 h-5"></span>
          </div>
          <h3 class="font-display font-semibold text-lg text-gray-900 dark:text-white mb-2">
            {{ currentLang === 'en' ? feature.title : feature.titleKh }}
          </h3>
          <p class="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">
            {{ currentLang === 'en' ? feature.desc : feature.descKh }}
          </p>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
defineProps({
  currentLang: String,
})

const stats = [
  { value: '99.9%', label: 'Uptime', labelKh: 'ពេលវេលាដំណើរការ', change: '+12% from last month' },
  { value: '50K+', label: 'Users', labelKh: 'អ្នកប្រើប្រាស់', change: '+23% growth' },
  { value: '24/7', label: 'Support', labelKh: 'ការគាំទ្យ', change: 'Always available' },
  { value: '$2.5M', label: 'Revenue', labelKh: 'ចំណូល', change: '+45% YoY' },
]

const features = [
  {
    title: 'AI-Powered',
    titleKh: 'ដំណើរការដោយ AI',
    desc: 'Leverage cutting-edge artificial intelligence to automate tasks and boost productivity.',
    descKh: 'ប្រើប្រាស់បច្ចេកវិទ្យា AI ទំនើបដើម្បីលុបលម្អការងារនិងបង្កើនផលិតភាពឯកទស។',
    color: 'bg-gradient-to-br from-blue-500 to-blue-600',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5h.01" /></svg>'
  },
  {
    title: 'Real-time Sync',
    titleKh: 'ធ្វើឱ្យស៉ីង្ក័របាន',
    desc: 'Keep your data synchronized across all devices in real-time with instant updates.',
    descKh: 'រក្សាទិន្នន័យរបស់អ្នកក្នុងលក្ខណៈស៉ីង្ក័រលើឧបករណ៍ទាំងអស់ភ្លាមៗ។',
    color: 'bg-gradient-to-br from-purple-500 to-purple-600',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>'
  },
  {
    title: 'Secure & Scalable',
    titleKh: 'សុវត្ថិ ដ៏ធំ',
    desc: 'Enterprise-grade security with automatic scaling to handle any volume of traffic.',
    descKh: 'សន្តិសុខលំដាប់សហគមន៍ដែលមានការសរសេរឡើងវិញដោយស្វ�័ត។',
    color: 'bg-gradient-to-br from-green-500 to-green-600',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>'
  },
  {
    title: 'Smart Analytics',
    titleKh: 'វិភាគប្រឹក្សាធម្មជាតិ',
    desc: 'Gain actionable insights with advanced analytics and detailed performance reports.',
    descKh: 'ទទួលបានការយល់ដឹងប្រាក់ប្រវ័ញ្ច ដែលមានលក្ខណៈឧទ្ធរណ៍នូវលម្អិត។',
    color: 'bg-gradient-to-br from-orange-500 to-orange-600',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>'
  },
  {
    title: 'Integrations',
    titleKh: 'ការរួមបញ្ចូលគ្នា',
    desc: 'Connect with 1000+ apps and services to streamline your workflow seamlessly.',
    descKh: 'ភ្ជាប់ជាមួយ 1000+ កម្មវិធីនិងសេវាកម្មដើម្បីឧក្រឹដ្ឋឯកគរណ៍។',
    color: 'bg-gradient-to-br from-pink-500 to-pink-600',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.658 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>'
  },
  {
    title: 'Mobile Ready',
    titleKh: 'ត្រៀមផ្តល់ឱ្យលក្ខណៈហាក់ដូច',
    desc: 'Fully responsive design that works perfectly on mobile, tablet, and desktop.',
    descKh: 'ការរចនាគ្រប់គ្រាន់ដែលដំណើរការបានល្អលើគ្រាប់ឱងហ្វូលទស។',
    color: 'bg-gradient-to-br from-cyan-500 to-cyan-600',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>'
  },
]
</script>

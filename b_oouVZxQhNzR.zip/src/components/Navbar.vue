<template>
  <nav class="navbar-glass fixed top-0 left-0 right-0 z-40 h-16">
    <div class="flex items-center justify-between h-full px-4 lg:px-6">
      <!-- Left: Hamburger + Logo -->
      <div class="flex items-center gap-3">
        <button 
          @click="$emit('toggle-sidebar')"
          class="p-2 rounded-lg hover:bg-brand-50 dark:hover:bg-brand-900/30 transition-colors text-gray-600 dark:text-gray-300">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/>
          </svg>
        </button>

        <!-- Logo -->
        <div class="flex items-center gap-2">
          <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center shadow-lg">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
              <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/>
            </svg>
          </div>
          <span class="font-display font-800 text-xl tracking-tight gradient-text hidden sm:block">Nexus</span>
        </div>
      </div>

      <!-- Center: Nav Menu (desktop) -->
      <div class="hidden md:flex items-center gap-1">
        <button 
          v-for="item in navItems" 
          :key="item.label"
          @click="$emit('set-page', item.page)"
          :class="['px-4 py-2 rounded-lg text-sm font-medium cursor-pointer transition-all',
                   activePage === item.page
                     ? 'bg-brand-100 dark:bg-brand-900/40 text-brand-600 dark:text-brand-400'
                     : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800/60 hover:text-gray-900 dark:hover:text-gray-100']">
          {{ currentLang === 'en' ? item.label : item.labelKh }}
        </button>
      </div>

      <!-- Right: Actions -->
      <div class="flex items-center gap-2">
        <!-- Dark Mode Toggle -->
        <button 
          @click="$emit('toggle-dark')"
          class="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800/60 transition-colors text-gray-600 dark:text-gray-300">
          <svg v-if="!isDark" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/>
          </svg>
          <svg v-else xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
            <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
            <line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
            <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
          </svg>
        </button>

        <!-- Language Switcher -->
        <div class="relative">
          <button 
            @click="langOpen = !langOpen"
            class="flex items-center gap-1.5 px-3 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800/60 transition-colors text-sm font-medium text-gray-600 dark:text-gray-300">
            <span>{{ currentLang === 'en' ? '🇺🇸' : '🇰🇭' }}</span>
            <span class="hidden sm:inline">{{ currentLang === 'en' ? 'EN' : 'KH' }}</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
              <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
            </svg>
          </button>

          <!-- Language Dropdown -->
          <div :class="['lang-dropdown absolute right-0 top-full mt-2 w-36 rounded-xl shadow-xl border border-gray-100 dark:border-gray-800 overflow-hidden z-50',
                        'bg-white dark:bg-gray-900',
                        langOpen ? 'lang-visible' : 'lang-hidden']">
            <button 
              v-for="lang in languages" 
              :key="lang.code"
              @click="selectLang(lang.code)"
              :class="['w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors',
                       currentLang === lang.code
                         ? 'bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 font-medium'
                         : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800/60']">
              <span>{{ lang.flag }}</span>
              <span>{{ lang.name }}</span>
            </button>
          </div>
        </div>

        <!-- Notifications -->
        <button class="relative p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800/60 transition-colors text-gray-600 dark:text-gray-300">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
          </svg>
          <span class="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500"></span>
        </button>

        <!-- Profile -->
        <div class="relative">
          <button 
            @click="profileOpen = !profileOpen"
            class="flex items-center gap-2 pl-1 pr-3 py-1 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800/60 transition-colors">
            <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white font-display font-bold text-sm">
              JD
            </div>
            <div class="hidden sm:block text-left">
              <p class="text-xs font-semibold text-gray-800 dark:text-gray-200 leading-tight">John Doe</p>
              <p class="text-xs text-gray-500 dark:text-gray-400 leading-tight">Admin</p>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-3 h-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
              <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
            </svg>
          </button>

          <!-- Profile Dropdown -->
          <div :class="['dropdown absolute right-0 top-full mt-2 w-56 rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-800 overflow-hidden z-50 bg-white dark:bg-gray-900',
                        profileOpen ? 'dropdown-visible' : 'dropdown-hidden']">
            <div class="px-4 py-3 border-b border-gray-100 dark:border-gray-800">
              <p class="font-semibold text-gray-800 dark:text-gray-100 text-sm">John Doe</p>
              <p class="text-xs text-gray-500 dark:text-gray-400">john@nexus.io</p>
            </div>
            <div class="py-1">
              <a 
                v-for="item in profileMenu" 
                :key="item.label"
                class="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800/60 cursor-pointer transition-colors"
                :class="item.danger ? 'text-red-500 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20' : ''">
                <span v-html="item.icon" class="w-4 h-4 flex-shrink-0"></span>
                {{ currentLang === 'en' ? item.label : item.labelKh }}
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>
</template>

<script setup>
import { ref } from 'vue'

defineProps({
  isDark: Boolean,
  currentLang: String,
  activePage: String,
})

defineEmits(['toggle-sidebar', 'toggle-dark', 'set-page', 'set-lang'])

const langOpen = ref(false)
const profileOpen = ref(false)

const languages = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'kh', name: 'ខ្មែរ', flag: '🇰🇭' },
]

const navItems = [
  { label: 'Home', labelKh: 'ទំព័រដើម', page: 'home' },
  { label: 'Dashboard', labelKh: 'ផ្ទាំងគ្រប់គ្រង', page: 'dashboard' },
  { label: 'Analytics', labelKh: 'វិភាគ', page: 'analytics' },
]

const profileMenu = [
  { label: 'Profile', labelKh: 'ប្រវត្តិ', icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>' },
  { label: 'Settings', labelKh: 'ការកំណត់', icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>' },
  { label: 'Logout', labelKh: 'ចាកចេញ', icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>', danger: true },
]

const selectLang = (code) => {
  langOpen.value = false
}
</script>

<template>
  <!-- Chat Toggle Button -->
  <button 
    @click="$emit('toggle-chat')"
    class="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-2xl shadow-brand-500/40 flex items-center justify-center hover:scale-110 transition-transform">
    <svg v-if="!chatOpen" xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
      <path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/>
    </svg>
    <svg v-else xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
      <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
    </svg>
    <span v-if="!chatOpen" class="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-green-400 border-2 border-white dark:border-gray-900"></span>
  </button>

  <!-- Chat Window -->
  <div :class="['chat-widget fixed bottom-24 right-6 z-50 w-80 sm:w-96 rounded-3xl shadow-2xl overflow-hidden',
                chatOpen ? 'chat-open' : 'chat-closed']"
       style="border: 1px solid rgba(99,102,241,0.2);">

    <!-- Chat Header -->
    <div class="bg-gradient-to-r from-brand-600 to-brand-700 px-5 py-4 flex items-center gap-3">
      <div class="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v3M15 17h2a2 2 0 002-2V9"/>
        </svg>
      </div>
      <div>
        <p class="text-white font-display font-semibold text-sm">
          {{ currentLang === 'en' ? 'Nexus AI' : 'AI Nexus' }}
        </p>
        <p class="text-white/70 text-xs">
          {{ currentLang === 'en' ? 'Always here to help' : 'នៅទីនេះជាប់ជានិច្ច' }}
        </p>
      </div>
      <div class="ml-auto flex items-center gap-1.5">
        <div class="w-2 h-2 rounded-full bg-green-400"></div>
        <span class="text-white/80 text-xs">{{ currentLang === 'en' ? 'Online' : 'អនឡាញ' }}</span>
      </div>
    </div>

    <!-- Messages -->
    <div class="chat-messages h-72 overflow-y-auto bg-gray-50 dark:bg-[#0f0f1e] p-4 space-y-3">
      <div 
        v-for="msg in messages" 
        :key="msg.id"
        :class="['flex', msg.role === 'user' ? 'justify-end' : 'justify-start']">
        <div :class="['max-w-[80%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed',
                      msg.role === 'user'
                        ? 'bg-brand-600 text-white rounded-br-sm'
                        : 'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 border border-gray-100 dark:border-gray-700 rounded-bl-sm shadow-sm']">
          {{ msg.content }}
        </div>
      </div>

      <!-- Typing indicator -->
      <div v-if="aiTyping" class="flex justify-start">
        <div class="flex items-center gap-1.5 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm">
          <div class="dot w-2 h-2 rounded-full bg-brand-400"></div>
          <div class="dot w-2 h-2 rounded-full bg-brand-400"></div>
          <div class="dot w-2 h-2 rounded-full bg-brand-400"></div>
        </div>
      </div>
    </div>

    <!-- Quick Prompts -->
    <div class="px-4 py-2 bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 flex gap-2 overflow-x-auto">
      <button 
        v-for="prompt in quickPrompts" 
        :key="prompt.en"
        @click="sendQuickPrompt(prompt)"
        class="flex-shrink-0 px-3 py-1.5 rounded-lg bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 text-xs font-medium hover:bg-brand-100 dark:hover:bg-brand-900/50 transition-colors">
        {{ currentLang === 'en' ? prompt.en : prompt.kh }}
      </button>
    </div>

    <!-- Input -->
    <div class="p-3 bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 flex items-center gap-2">
      <input 
        v-model="chatInput"
        @keyup.enter="sendMessage"
        :placeholder="currentLang === 'en' ? 'Ask me anything...' : 'សួរខ្ញុំអ្វីក៏បាន...'"
        class="flex-1 px-4 py-2.5 rounded-xl bg-gray-100 dark:bg-gray-800 text-sm text-gray-700 dark:text-gray-300 placeholder-gray-400 outline-none focus:ring-2 focus:ring-brand-400/40 transition border-none"/>
      <button 
        @click="sendMessage"
        :disabled="!chatInput.trim() || aiTyping"
        class="w-10 h-10 rounded-xl bg-brand-600 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-brand-700 active:scale-95 transition-all flex items-center justify-center flex-shrink-0">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
          <path stroke-linecap="round" stroke-linejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/>
        </svg>
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const props = defineProps({
  chatOpen: Boolean,
  currentLang: String,
})

defineEmits(['toggle-chat'])

const chatInput = ref('')
const aiTyping = ref(false)
const messages = ref([
  {
    id: 1,
    role: 'assistant',
    content: 'Hi! I&apos;m Nexus AI 👋 How can I help you today?'
  }
])

const quickPrompts = [
  { en: 'Help', kh: 'ជំនួយ' },
  { en: 'Settings', kh: 'ការកំណត់' },
  { en: 'Support', kh: 'ការគាំទ្យ' },
]

const sendMessage = async () => {
  if (!chatInput.value.trim() || aiTyping.value) return

  const userMessage = chatInput.value
  messages.value.push({
    id: messages.value.length + 1,
    role: 'user',
    content: userMessage
  })

  chatInput.value = ''
  aiTyping.value = true

  // Simulate AI response delay
  setTimeout(() => {
    messages.value.push({
      id: messages.value.length + 1,
      role: 'assistant',
      content: 'Thanks for your message! I&apos;m here to help. What would you like to know?'
    })
    aiTyping.value = false
  }, 1500)
}

const sendQuickPrompt = (prompt) => {
  chatInput.value = prompt.en
  sendMessage()
}
</script>
